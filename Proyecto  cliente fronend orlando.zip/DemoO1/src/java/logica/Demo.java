/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import java.util.List;

/**
 *
 * @author Usuario
 */
public class Demo {
    public static void main(String[] args) {
        Clientes a=new Clientes();
        //para   insertar y  guardar
        //a.setId_Cliente(2);
        //a.setNom_Cliente("juan");
        //a.setDire_Cliente("av la que sigue");
        //a.setTelefono_Cliente(3545);
        //a.setEmail_Cliente("a@gmail.com");
        //a.guardarClientes();
        
        //para actualizar
        //a.setId_Cliente(2);
        //a.setNom_Cliente("lulu");
        //a.setDire_Cliente("alli no  mas");
        //a.setTelefono_Cliente(3546);
        //a.setEmail_Cliente("lulu@gmail.com");
        //System.out.println(a.actualizarClientes());
        
        // para   eliminar
        a.setId_Cliente(2);
        System.out.println(a.eliminarClientes());
        
        //para   consultar
        List<Clientes> cliente=a.consultarClientes();
        for (Clientes cl : cliente) {
            System.out.println(cl.toString()); 
        }
    }
  
}
