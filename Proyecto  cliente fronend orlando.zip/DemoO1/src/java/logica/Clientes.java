/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import persistencia.ConexionBD;

/**
 *
 * @author Usuario
 */
public class Clientes {
    private int id_Cliente;
    private String nom_Cliente;
    private String dire_Cliente;
    private int telefono_Cliente;
    private String email_Cliente;

    public Clientes() {
    }

    public Clientes(int id_Cliente) {
        this.id_Cliente = id_Cliente;
    }

    public Clientes(int id_Cliente, String nom_Cliente, String dire_Cliente, int telefono_Cliente, String email_Cliente) {
        this.id_Cliente = id_Cliente;
        this.nom_Cliente = nom_Cliente;
        this.dire_Cliente = dire_Cliente;
        this.telefono_Cliente = telefono_Cliente;
        this.email_Cliente = email_Cliente;
    }

    public int getId_Cliente() {
        return id_Cliente;
    }

    public void setId_Cliente(int id_Cliente) {
        this.id_Cliente = id_Cliente;
    }

    public String getNom_Cliente() {
        return nom_Cliente;
    }

    public void setNom_Cliente(String nom_Cliente) {
        this.nom_Cliente = nom_Cliente;
    }

    public String getDire_Cliente() {
        return dire_Cliente;
    }

    public void setDire_Cliente(String dire_Cliente) {
        this.dire_Cliente = dire_Cliente;
    }

    public int getTelefono_Cliente() {
        return telefono_Cliente;
    }

    public void setTelefono_Cliente(int telefono_Cliente) {
        this.telefono_Cliente = telefono_Cliente;
    }

    public String getEmail_Cliente() {
        return email_Cliente;
    }

    public void setEmail_Cliente(String email_Cliente) {
        this.email_Cliente = email_Cliente;
    }

    @Override
    public String toString() {
        return "Clientes{" + "id_Cliente=" + id_Cliente + ", nom_Cliente=" + nom_Cliente + ", dire_Cliente=" + dire_Cliente + ", telefono_Cliente=" + telefono_Cliente + ", email_Cliente=" + email_Cliente + '}';
    }
    public List<Clientes>consultarClientes(){
        List<Clientes>cliente=new ArrayList<>();
        ConexionBD conexion= new ConexionBD();
        String sql ="SELECT * FROM clientes";
        ResultSet rs = conexion.consultarBD(sql);
        try{
            Clientes c;
            while(rs.next()){
                c =new Clientes();
                c.setId_Cliente(rs.getInt("id_Cliente"));
                c.setNom_Cliente(rs.getString("nom_Cliente"));
                c.setDire_Cliente(rs.getString("dire_Cliente"));
                c.setTelefono_Cliente(rs.getInt("telefono_Cliente"));
                c.setEmail_Cliente(rs.getString("email_Cliente"));
                cliente.add(c);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally{
            conexion.cerrarConexion();
        }

        return cliente;
    }
    
    public boolean guardarClientes(){
    boolean exito =false;
    ConexionBD conexion =new ConexionBD();
    String sql="INSERT INTO clientes(id_Cliente, nom_Cliente, dire_Cliente, telefono_Cliente, email_Cliente) VALUES("+id_Cliente+", '"+nom_Cliente+"', '"+dire_Cliente+"', "+telefono_Cliente+", '"+email_Cliente+"');";
    if(conexion.setAutoCommitBD(false)){
       if(conexion.insertarBD(sql)){
           exito=true;
           conexion.commitBD();
           conexion.cerrarConexion();
       }else{
           conexion.rollbackBD();
           conexion.cerrarConexion();
       } 
    }else{
        conexion.cerrarConexion();
    }
    
    return exito;
    }
    
    public boolean actualizarClientes(){
    boolean exito =false;
    ConexionBD conexion =new ConexionBD();
    String sql="UPDATE clientes SET nom_Cliente='"+nom_Cliente+"', dire_Cliente='"+dire_Cliente+"', telefono_Cliente="+telefono_Cliente+", email_Cliente='"+email_Cliente+"' WHERE id_Cliente="+id_Cliente+";";
    if(conexion.setAutoCommitBD(false)){
       if(conexion.actualizarBD(sql)){
           exito=true;
           conexion.commitBD();
           conexion.cerrarConexion();
       }else{
           conexion.rollbackBD();
           conexion.cerrarConexion();
       } 
    }else{
        conexion.cerrarConexion();
    }
    
    return exito;
    }
    
    public boolean eliminarClientes(){
    boolean exito =false;
    ConexionBD conexion =new ConexionBD();
    String sql="DELETE FROM producto.clientes WHERE id_Cliente="+id_Cliente+";";
    if(conexion.setAutoCommitBD(false)){
       if(conexion.actualizarBD(sql)){
           exito=true;
           conexion.commitBD();
           conexion.cerrarConexion();
       }else{
           conexion.rollbackBD();
           conexion.cerrarConexion();
       } 
    }else{
        conexion.cerrarConexion();
    }
    
    return exito;
    }
}
